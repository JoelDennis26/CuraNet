# crud/__init__.py
from .patients import *
from .doctors import *
from .appointments import *
from .admins import *
from .patient_dashboard_header import *
from .patient_profiles import *
from .patient_medical_history import *
from .patient_dashboard import *